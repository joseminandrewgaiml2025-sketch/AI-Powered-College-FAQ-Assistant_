"""
Capstone 13: AI-Powered FAQ Assistant for College
A small retrieval-first prototype using a local CSV knowledge base.
Run:
  python -m pip install streamlit pandas
  streamlit run faq_assistant_prototype.py

IMPORTANT:
- The supplied knowledge base contains templates and example.edu placeholder URLs.
- Replace every placeholder with verified official college content before real use.
- This demo uses keyword overlap, not an LLM; it avoids inventing answers.
"""
import re
import pandas as pd
import streamlit as st

DATA_FILE = "college_faq_knowledge_base.csv"
MIN_SCORE = 2

@st.cache_data
def load_data():
    df = pd.read_csv(DATA_FILE).fillna("")
    for col in ["question", "approved_answer_template", "source_url_placeholder", "keywords", "owner"]:
        if col not in df.columns:
            raise ValueError(f"Knowledge base is missing required column: {col}")
    return df

def tokens(text):
    return set(re.findall(r"[a-z0-9]+", str(text).lower()))

def retrieve(query, df):
    q = tokens(query)
    if not q:
        return None, 0
    best_row, best_score = None, 0
    for _, row in df.iterrows():
        searchable = " ".join([
            str(row.get("question", "")),
            str(row.get("keywords", "")),
            str(row.get("category", "")),
        ])
        score = len(q & tokens(searchable))
        # Small boost for overlap with question itself.
        score += 2 * len(q & tokens(str(row.get("question", ""))))
        if score > best_score:
            best_row, best_score = row, score
    return best_row, best_score

st.set_page_config(page_title="College FAQ Assistant", page_icon="🎓")
st.title("🎓 College FAQ Assistant")
st.caption("Answers are based only on the local approved FAQ knowledge base.")
st.warning("Demo data only: replace example.edu URLs and verify every answer with your college before publishing.")

try:
    df = load_data()
except Exception as exc:
    st.error(f"Could not load the knowledge base: {exc}")
    st.stop()

question = st.text_input("Ask a college question", placeholder="e.g., How do I renew a library book?")
if st.button("Find answer") and question.strip():
    row, score = retrieve(question, df)
    if row is None or score < MIN_SCORE:
        st.info("I don't have enough verified information to answer that confidently. Please check the official college website or contact the relevant office.")
    else:
        st.markdown(f"### {row['approved_answer_template']}")
        st.markdown(f"**Category:** {row.get('category', 'General')}")
        st.markdown(f"**Responsible office:** {row.get('owner', 'Relevant College Office')}")
        st.markdown(f"**Source:** {row.get('source_url_placeholder', '')}")
        st.caption("Please verify date-sensitive or policy-specific details with the responsible office.")
st.divider()
st.subheader("Privacy reminder")
st.write("Do not enter passwords, one-time codes, student IDs, financial details, or medical information.")
st.caption("Prototype limitation: keyword matching can miss paraphrases and may select a related but imperfect FAQ. Evaluate before deployment.")
