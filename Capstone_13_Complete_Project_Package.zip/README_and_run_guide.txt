CAPSTONE 13 — AI-POWERED FAQ ASSISTANT FOR COLLEGE
Project package and run guide

FILES
1. Capstone_13_AI_Powered_College_FAQ_Assistant.docx — full project report.
2. college_faq_knowledge_base.xlsx — editable FAQ table.
3. college_faq_knowledge_base.csv — data file used by the prototype.
4. faq_assistant_prototype.py — Streamlit demo app.
5. README_and_run_guide.txt — this guide.

IMPORTANT DATA NOTE
This is a complete academic project template, but no college name, official links, policies, or contacts were supplied. All example.edu links are placeholders. Before presenting this as a live institutional assistant, replace them with real, approved sources and verify every answer with the responsible college office. Do not claim that placeholder links are official.

HOW TO RUN ON WINDOWS
1. Install Python 3.10 or newer from the official Python website. During installation, select “Add Python to PATH”.
2. Put all project files in the same folder.
3. Open Command Prompt in that folder.
4. Run:
   py -m pip install streamlit pandas openpyxl
5. Run:
   py -m streamlit run faq_assistant_prototype.py
6. A browser tab should open. If not, copy the local URL shown in Command Prompt into your browser.
7. To stop the app, return to Command Prompt and press Ctrl+C.

HOW TO TEST
Try:
- How do I apply to the college?
- How do I renew a borrowed book?
- I cannot log in to my student account.
- What are the library opening hours?
- What is the exact scholarship deadline for next year? (should not invent a date; improve test/threshold if it returns a weak match)
- [a random unrelated question] (should fall back rather than guess)

BEFORE SUBMISSION
- Replace every placeholder source URL and check every answer.
- Add the real college name, project team, department, supervisor, and date to the report.
- Capture screenshots of the running prototype after using real approved content.
- Run the evaluation rubric and record actual results; do not present proposed targets as measured results.
- Follow your college's rules for AI assistance and cite sources as required.
